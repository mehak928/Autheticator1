const AdminCard = () => {
  return (
    <div>
      <h2>Admin Content</h2>
      <p>This is visible only to ADMIN role.</p>
    </div>
  );
};

export default AdminCard;