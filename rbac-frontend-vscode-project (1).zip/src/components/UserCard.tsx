const UserCard = () => {
  return (
    <div>
      <h2>User Content</h2>
      <p>This is visible only to USER role.</p>
    </div>
  );
};

export default UserCard;