import UserCard from "../components/UserCard";
import AdminCard from "../components/AdminCard";

const Dashboard = () => {
  const role = localStorage.getItem("role");

  return (
    <div>
      <h1>Dashboard</h1>
      {role === "USER" && <UserCard />}
      {role === "ADMIN" && <AdminCard />}
    </div>
  );
};

export default Dashboard;